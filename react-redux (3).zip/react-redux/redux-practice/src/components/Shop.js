import React from 'react'
import { useDispatch } from 'react-redux'
import { bindActionCreators } from 'redux';
import { actionCreator } from '../store'

const Shop = () => {


    const dispatch = useDispatch();
    const {depositMoney,withdraMoney} = bindActionCreators(actionCreator,dispatch);
  return (
    <div className='my-5'>
        <button className='btn-primary mx-2' onClick={()=> depositMoney(100)}> + </button>
        <button className=''> ADD TO CART</button>
         <button className='btn-primary mx-2' onClick={()=> withdraMoney(100)}> - </button> 

    </div>
  )
}

export default Shop