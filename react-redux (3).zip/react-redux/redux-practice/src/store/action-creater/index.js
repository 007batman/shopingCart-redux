export const depositMoney = (amount) =>{ //amount here is the state we are passing 
    return (dispatch) =>{
        dispatch({
            type: 'ADD',
            payload : amount 
        })
    }

}


export const withdraMoney = (amount) => {
    return (dispatch)=>{
        dispatch({
            type: 'MINUS',
            payload : amount
        })
    }
}