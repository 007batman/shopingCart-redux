const reducers = (state = 0,action) =>{
    if(action.type === 'ADD'){
       return state + action.payload
    }else if( action.type === "MINUS"){
        return state - action.payload
    }
    else {
        return state;
    }
}

export default reducers;